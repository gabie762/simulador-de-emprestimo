/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
 */

const tintColorLight = '#0066B3'; // azul Caixa
const tintColorDark = '#fff';

export const Colors = {
  light: {
    text: '#0066B3', // azul Caixa
    background: '#DCDDDD', // cinza claro Caixa
    tint: tintColorLight,
    icon: '#F7941E', // laranja Caixa
    tabIconDefault: '#757575', // cinza mais escuro para melhor visibilidade
    tabIconSelected: '#0066B3', // azul Caixa - ícones selecionados
  },
  dark: {
    text: '#ECEDEE',
    background: '#151718',
    tint: tintColorDark,
    icon: '#9BA1A6',
    tabIconDefault: '#757575', // cinza mais escuro para melhor visibilidade
    tabIconSelected: '#0066B3', // azul Caixa para ícones selecionados
  },
};
