// Re-export de todas as telas
export { default as CadastroProdutoScreen } from './CadastroProdutoScreen';
export { default as HomeScreen } from './HomeScreen';
export { default as ListaProdutosScreen } from './ListaProdutosScreen';
export { default as LoginScreen } from './LoginScreen';
export { default as SimulacaoScreen } from './SimulacaoScreen';

