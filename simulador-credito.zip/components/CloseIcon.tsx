import React from 'react';
import { Text } from 'react-native';

export const CloseIcon = () => (
  <Text style={{ fontSize: 24, color: '#fff' }}>×</Text>
);
